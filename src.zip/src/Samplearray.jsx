import React from 'react'

import {userData} from './data'
console.log(userData)

const Samplearray = () => {
  return (
    <div>
        {userData.map((user)=>{
            return(
                <div>
                    <div>{user.id} </div>
                    <div>{user.username} </div>
                    <div>{user.address.city} </div>
                    </div>
            )
        })}
    </div>
  )
}

export default Samplearray