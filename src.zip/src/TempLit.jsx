import React from 'react'

let Course = "React JS"

const TempLit = () => {
  return (
    <div>
        {`I am learning ${Course}`}
    </div>
  )
}

export default TempLit