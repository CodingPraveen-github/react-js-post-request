
import React from "react";
import './App.css';
import Firstcomp from "./Propartycomp/Firstcomp";
// import Secoundcomp from "./Propartycomp/Secoundcomp";
// import Forthcomp from "./Propartycomp/Forthcomp";
// import Thirdcomp from "./Propartycomp/Thirdcomp";
// import Statemgm from "./Statemgm";

import { useState } from "react";
// import Event from "./Event";
// import MouseOverEventExample from "./MouseOverEventExample";
// import Resize from "./Resize";
import FormExample from "./FormExample";
import Samplearray from "./Samplearray";
import TempLit from "./TempLit";
import UserPage from "./UserPage";
import Employeedetails from "./Employeedetails";






function App(){

  return (
    <div className="container" >
      <h1> This is Event Example</h1>
      {/* <Event />
      <MouseOverEventExample /> */}
      {/* <Resize /> */}
      {/* <FormExample /> */}
      {/* <Samplearray /> */}
      {/* <TempLit /> */}
      {/* <UserPage />
      < */}
      <Employeedetails />
      
    </div>
    
  )
}

export default App