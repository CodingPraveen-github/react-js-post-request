

import React from 'react'

import { useState } from 'react'

const Event = () => {

    const [number, setNumber] = useState(0)

    const Increment = () =>{
        setNumber (number + 1) 
    }

    const Decrement = () =>{
        if (number>0){
        setNumber (number - 1) 
        }
    }
    
    const Reset = () =>{
        setNumber (0) 
    }
    
  return (
    <div>
       <h2>{number}</h2> 
       <button onClick={Increment}>Increment</button>
       <button onClick={Decrement}>Decrement</button>
       <button onClick={Reset}>Reset</button>
    
    
    </div>
  )
}

export default Event