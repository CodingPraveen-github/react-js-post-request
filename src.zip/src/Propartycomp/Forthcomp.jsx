import React from 'react'

const Forthcomp = (props) => {
  return (
    <div>{props.name}</div>
  )
}

export default Forthcomp