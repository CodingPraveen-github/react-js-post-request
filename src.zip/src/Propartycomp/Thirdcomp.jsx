import React from 'react'

const Thirdcomp = (props) => {
  return (
    <div>{props.name}</div>
  )
}

export default Thirdcomp